const { UserInterestsModel } = require('./app');
const { findOneAndUpdate } = require('./app');

const exportUpdate = () => {
  const updateInterests = (req, res) => {
    if (req.isAuthenticated()) {
      // Retrieve the submitted form data
      const researchPapers1 = req.body.researchPapers1;
      const researchPapers2 = req.body.researchPapers2;
      const researchPapers3 = req.body.researchPapers3;

      const user = req.user.username;

      // Update the interests in the database
      UserInterestsModel.findOneAndUpdate(
        { user: user },
        {
          interest1: researchPapers1,
          interest2: researchPapers2,
          interest3: researchPapers3,
        },
        { new: true },
        (err, updatedInterests) => {
          if (err) {
            console.log(err);
            res.redirect('/');
          } else {
            // Redirect to the dashboard after updating the interests
            res.redirect('/Dashboard.html');
          }
        }
      );
    } else {
      res.redirect('/');
    }
  };

  return updateInterests;
};



module.exports = {
  exportUpdate
};

